Images PropertyMatch — ressources pédagogiques

Ces quatre photographies et cette illustration de remplacement sont fournies
uniquement pour construire l’application fictive PropertyMatch dans AI Academy.

Les logements, villes associées et annonces du cours sont fictifs.
Aucune image n’est chargée depuis une adresse distante.

Copiez uniquement les cinq fichiers visuels dans public/properties.
Ne copiez pas ce ZIP dans votre projet Next.js.
